﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Vishvajeet_Project_3.Utils.Enums
{
    public enum VarifyAccountEnum
    {
        OTPEXPIRED,
        OTPINVALID,
        OTPVERIFIED
    }
}
