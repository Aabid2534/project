﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Vishvajeet_Project_3.Models;
using Vishvajeet_Project_3.Models.ViewModel;
using Vishvajeet_Project_3.Utils.Enums;

namespace Vishvajeet_Project_3.Repository.Contract
{
    public interface IUser
    {
        SignUp Register(SignUp model);
        AuthoEnum AthenticateUser(SignIn model);
        VarifyAccountEnum VerifyUser(string otp);
        User UpdateProfile(string email,string path);
    }
}
