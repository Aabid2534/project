﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Vishvajeet_Project_3.Models.ViewModel;
using Vishvajeet_Project_3.Repository.Contract;
using Vishvajeet_Project_3.Utils.Enums;

namespace Vishvajeet_Project_3.Controllers
{
    public class UserController : Controller
    {
        private IUser userService;

        public IHostingEnvironment Environment { get; set; }

        public UserController(IUser userService,IHostingEnvironment environment)
        {
            this.userService = userService;
            Environment = environment;
        }

        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(SignIn model)
        {
            if (ModelState.IsValid)
            {
                var user = userService.AthenticateUser(model);
                if (user == AuthoEnum.SUCCESS)
                {
                    var identity = new ClaimsIdentity(new[] {
                    new Claim(ClaimTypes.Name,model.Email)
                    }, CookieAuthenticationDefaults.AuthenticationScheme);

                    var principal = new ClaimsPrincipal(identity);
                    var login = HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
                    return RedirectToAction("Index", "Home");
                }
                else if (user == AuthoEnum.FAILED)
                {
                    ModelState.AddModelError(string.Empty, "Invalid login creadential !");
                    return View();
                }
                else if (user == AuthoEnum.NOTVERIFIED)
                {
                    ModelState.AddModelError(string.Empty, "PLease varify Your Account !");
                    return View();
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "You are not a valid User !");
                    return View();
                }
            }
            else 
            {
                ModelState.AddModelError(string.Empty, "Please enter login details !");
                return View();
            }
        }
        public IActionResult LogOut()
        {
            var signout = HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login");
        }
        public IActionResult Verify()
        {

            return View();
        }
        [HttpPost]
        public IActionResult Verify(string otp)
        {
            if (otp != null)
            {
                var user = userService.VerifyUser(otp);
                if (user == VarifyAccountEnum.OTPVERIFIED)
                {
                    return RedirectToAction("Login");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Invalid otp");
                    return View();
                }
            }
            else
            {
                ModelState.AddModelError(string.Empty,"PLease enter OTP !");
                return View();
            }
            
        }
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Register(SignUp model)
        {
            if (ModelState.IsValid)
            {
                var user = userService.Register(model);
                if (user != null)
                {
                    return RedirectToAction("Verify");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Email already exist !");
                    return View();
                }
            }
            else
            {
                return View();
            }
           
        }
        public IActionResult UploadImage()
        {
            return View();
        }
        [HttpPost]
        public IActionResult UploadImage(string email)
        {
            var files = Request.Form.Files;
            if (files.Count > 0)
            {
                string path = Uploadfiles(files[0]);
                var user = userService.UpdateProfile(email, path);
                ViewBag.image = user;
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ModelState.AddModelError(string.Empty,"please select image");
                return View();
            }
           
        }

        private string Uploadfiles(IFormFile formFile)
        {
            var www = Environment.WebRootPath;
            string dbpath = string.Empty;
            var fullpath = Path.Combine(www,"wwwroot","images",formFile.FileName);
            FileStream stream = new FileStream(fullpath,FileMode.Create);
            dbpath = "images/" + formFile.FileName;
            formFile.CopyTo(stream);
            return $"{dbpath}";
        }
    }
}
