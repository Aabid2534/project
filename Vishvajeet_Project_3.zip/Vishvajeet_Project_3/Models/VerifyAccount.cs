﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Vishvajeet_Project_3.Models
{
    public class VerifyAccount
    {
        public int Id { get; set; }
        public string UserEmail { get; set; }
        public string OTP { get; set; }
        public DateTime Sendtime { get; set; }
    }
}
