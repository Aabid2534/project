﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;
using Vishvajeet_Project_3.Models;
using Vishvajeet_Project_3.Models.ViewModel;
using Vishvajeet_Project_3.Repository.Contract;
using Vishvajeet_Project_3.Utils.Enums;

namespace Vishvajeet_Project_3.Repository.Service
{
    public class UserService : IUser
    {
        private AppDbContext dbcon;
        public UserService(AppDbContext con) 
        {
            dbcon = con;
        }
        public AuthoEnum AthenticateUser(SignIn model)
        {
            var user = dbcon.users.SingleOrDefault(e=>e.Email==model.Email && e.Password==model.Password);
            if (user == null)
            {
                return AuthoEnum.FAILED;
            }
            else if (user.IsVerified == true)
            {
                return AuthoEnum.SUCCESS;
            }
            else if (user.IsVerified == false)
            {
                return AuthoEnum.NOTVERIFIED;
            }
            else
            {
                return AuthoEnum.NOTACTIVE;
            }
        }

        public SignUp Register(SignUp model)
        {
            if (dbcon.users.Any(e => e.Email == model.Email))
            {
                return null;
            }
            else
            {
                var user = new User()
                {
                    Name = model.Name,
                    Gender = model.Gender,
                    Email = model.Email,
                    Contact = model.Contact,
                    Password = model.Password,
                    ConfirmPassword = model.ConfirmPassword,
                    IsActive = true,
                    IsVerified = false,
                    Images=null
                };
                dbcon.users.Add(user);
                string Otp = GenerateOtp();
                SendMail(model.Email,Otp);
                var Vaccount = new VerifyAccount() 
                { 
                 OTP=Otp,
                 UserEmail=model.Email,
                 Sendtime=DateTime.Now
                };
                dbcon.verifyAccounts.Add(Vaccount);
                dbcon.SaveChanges();
                return model;
            }
        }

        private void SendMail(string email, string otp)
        {
            MailMessage mail = new MailMessage();
            mail.To.Add(email);
            mail.From = new MailAddress("vishvajeetchauhan2000@gmail.com");
            mail.Subject = "Verify Your Account";
            string body = $" Your otp is <strong>{email}</strong><b>:{otp}</b> <p>Thanks for Your Interest !";
            mail.Body = body;
            mail.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new System.Net.NetworkCredential("vishvajeetchauhan2000@gmail.com","123456789");
            smtp.EnableSsl = true;
            smtp.Send(mail);
        }

        private string GenerateOtp()
        {
            var chars= "ABCDEFGHIJKLMNOPQRST0123456789";
            var random = new Random();
            var list = Enumerable.Repeat(0, 8).Select(x=>chars[random.Next(chars.Length)]);
            var r = string.Join("",list);
            return r;
        }

        public User UpdateProfile(string email, string path)
        {
            throw new NotImplementedException();
        }

        public VarifyAccountEnum VerifyUser(string otp)
        {

            if (dbcon.verifyAccounts.Any(e => e.OTP == otp))
            {
                var ac = dbcon.verifyAccounts.SingleOrDefault(e => e.OTP == otp);
                var user = dbcon.users.SingleOrDefault(e => e.Email == ac.UserEmail);
                user.IsVerified = true;
                dbcon.verifyAccounts.Remove(ac);
                dbcon.users.Update(user);
                dbcon.SaveChanges();
                return VarifyAccountEnum.OTPVERIFIED;
            }
            else
            {
                return VarifyAccountEnum.OTPINVALID;
            }
        }
    }
}
